#include "prefetch.h"
#include "system.h"
#include <iostream>
#include <cstdlib>

using namespace std;

int NullPrefetch::prefetchMiss(uint64_t address __attribute__((unused)),
                              unsigned int tid __attribute__((unused)),
                              System* sys __attribute__((unused)))
{
   return 0;
}
int NullPrefetch::prefetchHit(uint64_t address __attribute__((unused)),
                           unsigned int tid __attribute__((unused)),
                           System* sys __attribute__((unused)))
{
   return 0;
}

// Implemetation of the Adjacent Prefetch
int AdjPrefetch::prefetchHit(uint64_t address __attribute__((unused)),
                           unsigned int tid __attribute__((unused)),
                          System* sys __attribute__((unused)))
{
	sys->memAccess(address+(1<<sys->SET_SHIFT), 'R', tid, true);
	return 1;
}

int AdjPrefetch::prefetchMiss(uint64_t address __attribute__((unused)),
                              unsigned int tid __attribute__((unused)),
                              System* sys __attribute__((unused)))
{
    sys->memAccess(address+(1<<sys->SET_SHIFT), 'R', tid, true);
	return 1;
}

SeqPrefetch::SeqPrefetch(int no)
{
	no_lines =  no;
}
// Implement Sequential Prefetch method.
// Number of lines to be varied can be found in the prefetch.h file
int SeqPrefetch::prefetchHit(uint64_t address __attribute__((unused)),
                           unsigned int tid __attribute__((unused)),
                           System* sys __attribute__((unused)))
{

	for(int i =1; i <= no_lines; i++){
		sys->memAccess(address+((1<<sys->SET_SHIFT)*i), 'R', tid, true);
	}
	return 1;

}

int SeqPrefetch::prefetchMiss(uint64_t address __attribute__((unused)),
                              unsigned int tid __attribute__((unused)),
                              System* sys __attribute__((unused)))
{
	for(int i =1; i<= no_lines; i++){
		sys->memAccess(address+((1<<sys->SET_SHIFT)*i), 'R', tid, true);
	}
    return 1;
} 

// Implement own prefetch method, try simple method. (Stride Prefetch)
int BestEffortPrefetch::prefetchHit(uint64_t address __attribute__((unused)),
                           unsigned int tid __attribute__((unused)),
                           System* sys __attribute__((unused)))
{
		no_hits++;

		if(no_hits > 3 && stride < 10)
			stride++;

		for(int i =1; i<= 4; i++){
		 	sys->memAccess(address+(64*i), 'R', tid, true);
		}

		for(int i =1; i<= 3; i++){
		 	sys->memAccess(address - (64*i), 'R', tid, true);
		}

		return 1;
}

int BestEffortPrefetch::prefetchMiss(uint64_t address __attribute__((unused)),
                              unsigned int tid __attribute__((unused)),
                              System* sys __attribute__((unused)))
{		
		no_miss++;
		no_hits = 0;

		if(stride > 0)
			stride --;

		for(int i =1; i<=stride; i++){
			sys->memAccess(address+ (64*i), 'R', tid, true);
		}

		for(int i =1; i<=5; i++){
			sys->memAccess(address- (64*i), 'R', tid, true);
		}

		return 1;
}