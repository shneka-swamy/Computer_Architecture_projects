Please use the following commands to compile the file.
The results for the commands are also provided in the document.

1. make
2. 
./cache --prefetch AdjPrefetch

Accesses: 496611
Hits: 495755
Misses: 856
Local reads: 852
Local writes: 284
Remote reads: 0
Remote writes: 0
Other-cache reads: 0
Pre Fetched: 496607
Hit Ratio: 99.8276

3.  
./cache --prefetch SeqPrefetch

Enter the number of lines to prefetch
10
Accesses: 496611
Hits: 496036
Misses: 575
Local reads: 571
Local writes: 519
Remote reads: 0
Remote writes: 0
Other-cache reads: 0
Pre Fetched: 496607
Hit Ratio: 99.8842


4.  

./cache --prefetch BestEffortPrefetch

Accesses: 496611
Hits: 496179
Misses: 432
Local reads: 428
Local writes: 523
Remote reads: 0
Remote writes: 0
Other-cache reads: 0
Pre Fetched: 496607
Hit Ratio: 99.913


